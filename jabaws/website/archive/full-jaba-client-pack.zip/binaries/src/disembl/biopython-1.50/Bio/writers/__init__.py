"""Part of an old unused and undocumented sequence writing framework (DEPRECATED)."""
# This is a Python module.
# (there are more files underneath this directory)

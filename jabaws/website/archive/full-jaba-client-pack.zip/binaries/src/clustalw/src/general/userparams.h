/**
 * Author: Mark Larkin
 * 
 * Copyright (c) 2007 Des Higgins, Julie Thompson and Toby Gibson.  
 */
#ifndef USERPARAMS_H
#define USERPARAMS_H
#include "UserParameters.h"
namespace clustalw
{
// MARK Dec 12 2005
extern UserParameters *userParameters;
}
#endif



